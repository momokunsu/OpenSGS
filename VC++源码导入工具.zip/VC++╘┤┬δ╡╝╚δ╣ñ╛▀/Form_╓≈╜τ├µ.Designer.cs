﻿namespace VC__源码导入工具
{
    partial class Form_主界面
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_主界面));
            this.label2 = new System.Windows.Forms.Label();
            this.TBox_项目路径 = new System.Windows.Forms.TextBox();
            this.BT_浏览项目 = new System.Windows.Forms.Button();
            this.OFDialog = new System.Windows.Forms.OpenFileDialog();
            this.BT_浏览源码 = new System.Windows.Forms.Button();
            this.TBox_源码路径 = new System.Windows.Forms.TextBox();
            this.LB_导入进度 = new System.Windows.Forms.Label();
            this.FBDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.BT_开始导入 = new System.Windows.Forms.Button();
            this.PBar_导入进度 = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "请选择项目工程文件(*.vcxproj)";
            // 
            // TBox_项目路径
            // 
            this.TBox_项目路径.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBox_项目路径.Location = new System.Drawing.Point(12, 31);
            this.TBox_项目路径.Name = "TBox_项目路径";
            this.TBox_项目路径.Size = new System.Drawing.Size(469, 21);
            this.TBox_项目路径.TabIndex = 12;
            this.TBox_项目路径.Text = "F:\\VC++工作文件夹\\OpenSGS\\OpenSGS-Server\\OpenSGS-Server.vcxproj";
            this.TBox_项目路径.TextChanged += new System.EventHandler(this.TBox_Path_TextChanged);
            // 
            // BT_浏览项目
            // 
            this.BT_浏览项目.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BT_浏览项目.Location = new System.Drawing.Point(487, 29);
            this.BT_浏览项目.Name = "BT_浏览项目";
            this.BT_浏览项目.Size = new System.Drawing.Size(54, 23);
            this.BT_浏览项目.TabIndex = 13;
            this.BT_浏览项目.Text = "浏览";
            this.BT_浏览项目.UseVisualStyleBackColor = true;
            this.BT_浏览项目.Click += new System.EventHandler(this.BT_浏览项目_Click);
            // 
            // OFDialog
            // 
            this.OFDialog.Filter = "VC工程文件|*.vcxproj";
            // 
            // BT_浏览源码
            // 
            this.BT_浏览源码.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BT_浏览源码.Location = new System.Drawing.Point(487, 82);
            this.BT_浏览源码.Name = "BT_浏览源码";
            this.BT_浏览源码.Size = new System.Drawing.Size(54, 23);
            this.BT_浏览源码.TabIndex = 13;
            this.BT_浏览源码.Text = "浏览";
            this.BT_浏览源码.UseVisualStyleBackColor = true;
            this.BT_浏览源码.Click += new System.EventHandler(this.BT_浏览源码_Click);
            // 
            // TBox_源码路径
            // 
            this.TBox_源码路径.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBox_源码路径.Location = new System.Drawing.Point(12, 84);
            this.TBox_源码路径.Name = "TBox_源码路径";
            this.TBox_源码路径.Size = new System.Drawing.Size(469, 21);
            this.TBox_源码路径.TabIndex = 12;
            this.TBox_源码路径.Text = "F:\\VC++工作文件夹\\OpenSGS\\OpenSGS-Server\\src";
            this.TBox_源码路径.TextChanged += new System.EventHandler(this.TBox_Path_TextChanged);
            // 
            // LB_导入进度
            // 
            this.LB_导入进度.AutoSize = true;
            this.LB_导入进度.Location = new System.Drawing.Point(137, 141);
            this.LB_导入进度.Name = "LB_导入进度";
            this.LB_导入进度.Size = new System.Drawing.Size(0, 12);
            this.LB_导入进度.TabIndex = 14;
            // 
            // BT_开始导入
            // 
            this.BT_开始导入.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BT_开始导入.Enabled = false;
            this.BT_开始导入.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BT_开始导入.Location = new System.Drawing.Point(12, 351);
            this.BT_开始导入.Name = "BT_开始导入";
            this.BT_开始导入.Size = new System.Drawing.Size(119, 66);
            this.BT_开始导入.TabIndex = 13;
            this.BT_开始导入.Text = "开始导入";
            this.BT_开始导入.UseVisualStyleBackColor = true;
            this.BT_开始导入.Click += new System.EventHandler(this.BT_开始导入_Click);
            // 
            // PBar_导入进度
            // 
            this.PBar_导入进度.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PBar_导入进度.Location = new System.Drawing.Point(147, 384);
            this.PBar_导入进度.Name = "PBar_导入进度";
            this.PBar_导入进度.Size = new System.Drawing.Size(394, 33);
            this.PBar_导入进度.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 12);
            this.label3.TabIndex = 14;
            this.label3.Text = "请选择源码文件夹";
            // 
            // treeView1
            // 
            this.treeView1.AllowDrop = true;
            this.treeView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(12, 111);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "节点1";
            treeNode1.Text = "节点1";
            treeNode2.Name = "节点1";
            treeNode2.Text = "节点1";
            treeNode3.Name = "节点2";
            treeNode3.Text = "节点2";
            treeNode4.Name = "节点0";
            treeNode4.SelectedImageIndex = 0;
            treeNode4.Text = "节点0";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(529, 234);
            this.treeView1.StateImageList = this.imageList1;
            this.treeView1.TabIndex = 16;
            this.treeView1.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.treeView1_ItemDrag);
            this.treeView1.NodeMouseHover += new System.Windows.Forms.TreeNodeMouseHoverEventHandler(this.treeView1_NodeMouseHover);
            this.treeView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeView1_DragDrop);
            this.treeView1.MouseCaptureChanged += new System.EventHandler(this.treeView1_MouseCaptureChanged);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "雷.bmp");
            // 
            // Form_主界面
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 429);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.PBar_导入进度);
            this.Controls.Add(this.LB_导入进度);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBox_源码路径);
            this.Controls.Add(this.BT_开始导入);
            this.Controls.Add(this.BT_浏览源码);
            this.Controls.Add(this.TBox_项目路径);
            this.Controls.Add(this.BT_浏览项目);
            this.Name = "Form_主界面";
            this.Text = "VC++源码导入工具";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBox_项目路径;
        private System.Windows.Forms.Button BT_浏览项目;
        private System.Windows.Forms.OpenFileDialog OFDialog;
        private System.Windows.Forms.Button BT_浏览源码;
        private System.Windows.Forms.TextBox TBox_源码路径;
        private System.Windows.Forms.Label LB_导入进度;
        private System.Windows.Forms.FolderBrowserDialog FBDialog;
        private System.Windows.Forms.Button BT_开始导入;
        private System.Windows.Forms.ProgressBar PBar_导入进度;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
    }
}

