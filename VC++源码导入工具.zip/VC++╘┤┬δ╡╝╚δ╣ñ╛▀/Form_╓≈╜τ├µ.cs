﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace VC__源码导入工具
{
    public partial class Form_主界面 : Form
    {
        public Form_主界面()
        {
            InitializeComponent();
            TBox_Path_TextChanged(null, null);
        }

        private void BT_浏览项目_Click(object sender, EventArgs e)
        {
            if (File.Exists(TBox_项目路径.Text))
            {
                OFDialog.InitialDirectory = Path.GetDirectoryName(TBox_项目路径.Text);
            }

            OFDialog.ShowDialog(this);
            if (File.Exists(OFDialog.FileName))
            {
                TBox_项目路径.Text = OFDialog.FileName;
            }
        }

        private void BT_浏览源码_Click(object sender, EventArgs e)
        {
            if (File.Exists(TBox_项目路径.Text))
            {
                FBDialog.SelectedPath = TBox_源码路径.Text;
            }

            FBDialog.ShowDialog(this);
            if (Directory.Exists(FBDialog.SelectedPath))
            {
                TBox_源码路径.Text = FBDialog.SelectedPath;
            }
        }

        private void BT_开始导入_Click(object sender, EventArgs e)
        {
            TBox_源码路径.Text = TBox_源码路径.Text.TrimEnd('\\');
            var src_dir = Path.GetFileName(TBox_源码路径.Text);
            try
            {
                //读取项目文档
                var proj_doc = new XmlDocument();
                proj_doc.Load(TBox_项目路径.Text);

                //读取项目筛选器文档
                var filter_doc = new XmlDocument();
                var filter_file = TBox_项目路径.Text.Replace(".vcxproj", ".vcxproj.filters");
                filter_doc.Load(filter_file);

                var proj_xmlmgr = new XmlNamespaceManager(proj_doc.NameTable);
                proj_xmlmgr.AddNamespace("x", proj_doc["Project"].NamespaceURI);

                //清除文件
                removeNodes(proj_doc.SelectNodes("/x:Project/x:ItemGroup", proj_xmlmgr), (item) =>
                {
                    return item["ClCompile"] != null || item["ClInclude"] != null;
                });
                removeNodes(filter_doc.SelectNodes("/x:Project/x:ItemGroup", proj_xmlmgr), (item) =>
                {
                    return item["ClCompile"] != null || item["ClInclude"] != null;
                });
                removeNodes(filter_doc.SelectNodes("/x:Project/x:ItemGroup/x:Filter", proj_xmlmgr), (item) =>
                {
                    var attr = item.Attributes["Include"];
                    if (attr != null)
                    {
                        return attr.Value.Split('\\')[0] == src_dir;
                    }
                    return false;
                });

                //创建筛选器
                var filter_root = filter_doc.SelectSingleNode("/x:Project/x:ItemGroup/x:Filter", proj_xmlmgr);
                if (filter_root == null)
                {
                    filter_root = AddNode(filter_doc["Project"], "ItemGroup");
                }
                else
                {
                    filter_root = filter_root.ParentNode;
                }

                var filter_dir = Path.GetDirectoryName(TBox_源码路径.Text);
                var filters = new List<string>();
                filters.Add(TBox_源码路径.Text);
                filters.AddRange(Directory.GetDirectories(TBox_源码路径.Text, "*", SearchOption.AllDirectories));

                foreach (var filter in filters)
                {
                    var filter_name = filter.Replace(filter_dir, "").TrimStart('\\').TrimEnd('\\');
                    var node_filter = AddNode(filter_root, "Filter");
                    node_filter.SetAttribute("Include", filter_name);
                    AddNode(node_filter, "UniqueIdentifier").InnerText = string.Format("{{{0}}}", Guid.NewGuid().ToString());
                }

                //导入文件
                var relative_path = calcRelativePath(TBox_源码路径.Text, TBox_项目路径.Text);
                var files = Directory.GetFiles(TBox_源码路径.Text, "*.*", SearchOption.AllDirectories);
                var proj_com_root = AddNode(proj_doc["Project"], "ItemGroup", proj_doc.SelectSingleNode("/x:Project/x:ItemGroup/x:ProjectConfiguration", proj_xmlmgr).ParentNode);
                var proj_inc_root = AddNode(proj_doc["Project"], "ItemGroup", proj_com_root);
                var filter_com_root = AddNode(filter_doc["Project"], "ItemGroup", filter_root);
                var filter_inc_root = AddNode(filter_doc["Project"], "ItemGroup", filter_com_root);
                PBar_导入进度.Maximum = files.Length;
                PBar_导入进度.Value = 0;
                foreach (var file in files)
                {
                    var file_name = file.Replace(filter_dir, "").TrimStart('\\').TrimEnd('\\');
                    var file_path = Path.Combine(relative_path, file_name);

                    var ext = Path.GetExtension(file_name);
                    if (ext == ".cpp" || ext == ".c")
                    {
                        AddNode(proj_com_root, "ClCompile").SetAttribute("Include", file_path);
                        var filter_node = AddNode(filter_com_root, "ClCompile");
                        filter_node.SetAttribute("Include", file_path);
                        AddNode(filter_node, "Filter").InnerText = Path.GetDirectoryName(file_name);
                    }
                    else
                    {
                        AddNode(proj_inc_root, "ClInclude").SetAttribute("Include", file_path);
                        var filter_node = AddNode(filter_inc_root, "ClInclude");
                        filter_node.SetAttribute("Include", file_path);
                        AddNode(filter_node, "Filter").InnerText = Path.GetDirectoryName(file_name);
                    }

                    LB_导入进度.Text = file_name;
                    PBar_导入进度.Value++;
                    Refresh();
                }

                proj_doc.Save(TBox_项目路径.Text);
                filter_doc.Save(filter_file);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString(), "异常!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TBox_Path_TextChanged(object sender, EventArgs e)
        {
            BT_开始导入.Enabled = Path.GetPathRoot(TBox_项目路径.Text) == Path.GetPathRoot(TBox_源码路径.Text)
                                && File.Exists(TBox_项目路径.Text)
                                && Directory.Exists(TBox_源码路径.Text);
        }

        private string calcRelativePath(string path1, string path2)
        {
            var path1_dir = Path.GetDirectoryName(path1);
            var path2_dir = Path.GetDirectoryName(path2);

            var relative_path = "";
            while (path2_dir != null && path1_dir.IndexOf(path2_dir) < 0)
            {
                relative_path += "..\\";
                path2_dir = Path.GetDirectoryName(path2_dir);
            }
            return relative_path + path1_dir.Replace(path2_dir, "").TrimStart('\\').TrimEnd('\\');
        }

        private XmlElement AddNode(XmlNode parent, string node_name, XmlNode node_index = null)
        {
            var node = parent.OwnerDocument.CreateElement(node_name, parent.NamespaceURI);
            if (node_index == null)
            {
                parent.AppendChild(node);
            }
            else
            {
                parent.InsertAfter(node, node_index);
            }
            return node;
        }

        private void removeNodes(XmlNodeList list, Func<XmlNode, bool> func)
        {
            foreach (XmlNode item in list)
            {
                if (func(item))
                {
                    item.ParentNode.RemoveChild(item);
                }
            }
        }

        private void treeView1_ItemDrag(object sender, ItemDragEventArgs e)
        {
            Console.WriteLine(e.Item);
            //Console.WriteLine(e.ToString());
        }

        private void treeView1_DragDrop(object sender, DragEventArgs e)
        {
            return;
        }

        private void treeView1_MouseCaptureChanged(object sender, EventArgs e)
        {
        }

        private void treeView1_NodeMouseHover(object sender, TreeNodeMouseHoverEventArgs e)
        {
            Console.WriteLine(e.Node);
        }
    }
}
