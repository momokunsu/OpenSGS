
--------------------------------
-- @module NetManager
-- @parent_module 

--------------------------------
-- 
-- @function [parent=#NetManager] setExtend1 
-- @param self
-- @param #char val
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getDataLen 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getPos 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#NetManager] readDword 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#NetManager] move 
-- @param self
-- @param #int pos
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] setIndex 
-- @param self
-- @param #int val
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getServerId 
-- @param self
-- @return char#char ret (return value: char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] readByte 
-- @param self
-- @return unsigned char#unsigned char ret (return value: unsigned char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] connect 
-- @param self
-- @param #char pszServerIP
-- @param #int nServerPort
-- @param #int nBlockSec
-- @param #bool bKeepAlive
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#NetManager] readDouble 
-- @param self
-- @return double#double ret (return value: double)
        
--------------------------------
-- 
-- @function [parent=#NetManager] setServerId 
-- @param self
-- @param #char val
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getExtend2 
-- @param self
-- @return char#char ret (return value: char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getExtend1 
-- @param self
-- @return char#char ret (return value: char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getIndex 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#NetManager] writeText 
-- @param self
-- @param #char str
-- @param #int len
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] setUserId 
-- @param self
-- @param #char str
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] writeWord 
-- @param self
-- @param #unsigned short s
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] readWord 
-- @param self
-- @return unsigned short#unsigned short ret (return value: unsigned short)
        
--------------------------------
-- 
-- @function [parent=#NetManager] readFloat 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#NetManager] writeDouble 
-- @param self
-- @param #double d
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] send 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#NetManager] writeFloat 
-- @param self
-- @param #float f
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] readText 
-- @param self
-- @param #int len
-- @return char#char ret (return value: char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] writeDword 
-- @param self
-- @param #unsigned int l
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] writeByte 
-- @param self
-- @param #unsigned char c
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] setExtend2 
-- @param self
-- @param #char val
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] setCommand 
-- @param self
-- @param #int val
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getTag 
-- @param self
-- @return char#char ret (return value: char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getUserId 
-- @param self
-- @return char#char ret (return value: char)
        
--------------------------------
-- 
-- @function [parent=#NetManager] reset 
-- @param self
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getCommand 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#NetManager] moveToEnd 
-- @param self
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] setTag 
-- @param self
-- @param #char val
-- @return NetManager#NetManager self (return value: NetManager)
        
--------------------------------
-- 
-- @function [parent=#NetManager] getInstance 
-- @param self
-- @return NetManager#NetManager ret (return value: NetManager)

function NetManager:serialize(pack)
	self:reset()

	local res
	res = pack.extend1 and self:setExtend1(pack.extend1)
	res = pack.extend2 and self:setExtend2(pack.extend2)
	res = pack.userid and self:setUserId(pack.userid)
	res = pack.serverid and self:setServerId(pack.serverid)
	res = pack.index and self:setIndex(pack.index)
	res = pack.command and self:setCommand(pack.command)

	if pack.data ~= nil then
		for k,v in pairs(pack.data) do
			if type(v.byte) == "number" then
				self:writeByte(v.byte)
			elseif type(v.int) == "number" then
				self:writeDword(v.int)
			elseif type(v.string) == "string" then
				self:writeText(v.string, v.len)
			elseif type(v.table) == "table" then
				local tab = { data = v.table }
				self:serialize(tab)
			else
				assert(false, "unknown data type !!!")
			end
		end
	end
end

function NetManager:deSerialize(pack)
	self:reset()

	pack.extend1 = self:getExtend1()
	pack.extend2 = self:getExtend2()
	pack.userid = self:getUserId()
	pack.serverid = self:getServerId()
	pack.index = self:getIndex()
	pack.command = self:getCommand()

	if pack.data ~= nil then
		for k,v in pairs(pack.data) do
			if type(v.byte) == "number" then
				v.byte = self:readByte()
			elseif type(v.int) == "number" then
				v.int = self:readDword()
			elseif type(v.string) == "string" then
				v.string = self:readText(v.len)
			elseif type(v.table) == "table" then
				local tab = { data = v.table }
				self:deSerialize(tab)
			else
				assert(false, "unknown data type !!!")
			end
		end
	end
end

return NetManager:getInstance()
