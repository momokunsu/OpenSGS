-- 1001-游戏启动
Protocol.PlatformType = { Android = 1, IOS = 2 }
CSProtocol[1001] = {
    command  = 1001,
    extend1  = 0,
    extend2  = 0,
    index    = 1000000,
    serverid = 0,
    userid   = "",
    data = {
    	_1_version = { string = "", len = 8},
    	_2_os = { byte = 1 },
	}
}

SCProtocol[1001] = {
    command  = 1001,
    extend1  = 0,
    extend2  = 0,
    index    = 1000000,
    serverid = 0,
    userid   = "",
    data = {
    	_1_resultcode = { byte = 0 },
    	_2_version = { string = "", len = 8},
	}
}

-- 1002-游戏登录
CSProtocol[1002] = {
    command  = 1002,
    extend1  = 0,
    extend2  = 0,
    index    = 1000000,
    serverid = 0,
    userid   = "",
    data = {
    	_1_src = { byte = 0 },
    	_2_openid = { string = "", len = 128},
    	_3_nickname = { string = "", len = 128},
    	_4_icon = { string = "", len = 256},
	}
}

SCProtocol[1002] = {
    command  = 1002,
    extend1  = 0,
    extend2  = 0,
    index    = 1000000,
    serverid = 0,
    userid   = "",
    data = {
    	_1_resultcode = { byte = 0 },
    	_2_heartbeat = { byte = 0 },
    	_3_cardnum = { int = 0 },
    	_4_tableid = { int = 0 },
	}
}

