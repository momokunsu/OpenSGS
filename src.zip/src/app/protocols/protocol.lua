Protocol = Protocol or {}
CSProtocol = CSProtocol or {}
SCProtocol = SCProtocol or {}

require("app.protocols.protocol1000")

CMD = CMD or {
	Login = 1001 -- 1001-游戏启动
}

-- 协议工厂
-- @param self
-- @param #int val
function Protocol:create(cmd_type, cmd)
	if cmd_type == "c2s" then
		return clone(CSProtocol[cmd])
	elseif cmd_type == "s2c" then
		return clone(SCProtocol[cmd])
	else
		assert(false, "invaild cmd_type !!!")
	end
end