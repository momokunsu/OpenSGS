#include "base/ccConfig.h"
#ifndef __user_h__
#define __user_h__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_user(lua_State* tolua_S);




































#endif // __user_h__
