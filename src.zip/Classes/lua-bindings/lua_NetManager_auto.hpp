#include "base/ccConfig.h"
#ifndef __net_h__
#define __net_h__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_net(lua_State* tolua_S);




































#endif // __net_h__
