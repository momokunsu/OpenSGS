#pragma once

#include "GameSocket.h"
#include "Packet.h"


class NetManager
{
	public:
		static NetManager *getInstance();

		bool connect(const char* pszServerIP, int nServerPort, int nBlockSec = BLOCKSECONDS, bool bKeepAlive = false);
		bool send();
		void respone(Packet *pack) { m_respone_cb && (m_respone_cb(pack), true); }
		void setOnDisConnectCallback(std::function<void()> func) { m_socket->setOnDisConnectCallback(func); }
		std::function<void()> getOnDisConnectCallback() { m_socket->getOnDisConnectCallback(); }
		void setOnResponeCallback(std::function<void(Packet *pack)> func) { m_respone_cb = func; }
		std::function<void(Packet *pack)> getOnResponeCallback() { return m_respone_cb; }

		int getPos() const { return m_packet_stream->getPos(); }

		void reset() { m_packet_stream->reset(); }
		void move(int pos) { m_packet_stream->move(pos); }
		void moveToEnd() { m_packet_stream->moveToEnd(); }

		int8	getTag() { return m_packet_stream->getTag();}
		void	setTag(int8 val) { m_packet_stream->setTag(val); }
		int8	getExtend1() { return m_packet_stream->getExtend1(); }
		void	setExtend1(int8 val) { m_packet_stream->setExtend1(val); }
		int8	getExtend2() { return m_packet_stream->getExtend2(); }
		void	setExtend2(int8 val) { m_packet_stream->setExtend2(val); }
		const char * getUserId() { return m_packet_stream->getUserId(); }
		void setUserId(const char * str) { m_packet_stream->setUserId(str); }
		int8	getServerId() { return m_packet_stream->getServerId(); }
		void	setServerId(int8 val) { m_packet_stream->setServerId(val); }
		int32 getIndex() { return m_packet_stream->getIndex(); }
		void setIndex(int32 val) { m_packet_stream->setIndex(val); }
		int32 getCommand() { return m_packet_stream->getCommand(); }
		void setCommand(int32 val) { m_packet_stream->setCommand(val); }
		int32 getDataLen() { return m_packet_stream->getDataLen(); }

		uint8 readByte() { return m_packet_stream->readByte(); }
		uint16 readWord() { return m_packet_stream->readWord(); }
		uint32 readDword() { return m_packet_stream->readDword(); }
		uint64 readDDword() { return m_packet_stream->readDDword(); }
		float readFloat() { return m_packet_stream->readFloat(); }
		double readDouble() { return m_packet_stream->readDouble(); }
		const char * readText(int len) { return m_packet_stream->readText(len); }
		void * readData(int len) { return m_packet_stream->readData(len); }

		void writeByte(uint8 c) { m_packet_stream->writeByte(c); }
		void writeWord(uint16 s) { m_packet_stream->writeWord(s); }
		void writeDword(uint32 l) { m_packet_stream->writeDword(l); }
		void writeDDword(uint64 ll) { m_packet_stream->writeDDword(ll); }
		void writeFloat(float f) { m_packet_stream->writeFloat(f); }
		void writeDouble(double d) { m_packet_stream->writeDouble(d); }
		void writeText(const char *str, int len) { m_packet_stream->writeText(str, len); }
		void writeData(void *data, int len) { m_packet_stream->writeData(data,len); }

		GameSocket * getSocket() { return m_socket; }
		Packet * getPacket() { return m_packet; }
		PacketStream * getPacketStream() { return m_packet_stream; }

	private:
		NetManager();
		virtual ~NetManager();

		static NetManager* self;

		GameSocket *m_socket;
		Packet *m_packet;
		PacketStream *m_packet_stream;

		std::function<void(Packet *pack)> m_respone_cb;
};

