#pragma once

#include <functional>

#include "def.h"

#pragma pack(push)
#pragma pack(1)

#define HEADERSIZE (sizeof(PackHeader))
#define PACKETSIZE (sizeof(Packet))

struct PackHeader
{
	int8 Tag;					// Э��ͷ��־λ, 0x01
	int8 Extend1;			// Ԥ����������չЭ��
	int8 Extend2;			// Ԥ����������չЭ��
	char UserId[32];	// �û�id�������ÿո������
	int8 ServerId;		// Ѱַʱ����ķ�����id
	int32 Index;			// ����ţ�C / S����ά�����Եģ�1000000��9999999
	int32 Command;		// Э���
	int32 DataLen;		// data����

	PackHeader()
	{
		Tag = 0x01;
		Extend1 = Extend2 = 0;
		memset(UserId, ' ', sizeof(PackHeader::UserId));
		ServerId = 0;
		Index = 1000000;
		Command = 0;
		DataLen = 0;
	}
};

struct Packet
{
	PackHeader Header;
	int8 Data[1024 - HEADERSIZE];	// ��������󳤶Ȳ��ó���1024��

	Packet() {}
	Packet& operator=(const Packet& pack)
	{
		Header = pack.Header;
		memcpy(Data, pack.Data, Header.DataLen);
		return *this;
	}

	void* getData() { return this; }
	int getPacketSize() { return HEADERSIZE + Header.DataLen; }
};
#pragma pack(pop)

class PacketStream
{
	friend class PacketStream;
	public:
		PacketStream(Packet *pack);
		virtual ~PacketStream();

		int getPos() const { return m_pos; }

		void reset();
		void move(int pos) { m_pos = pos; }
		void moveToEnd();

		int8	getTag() { return m_buffer->Header.Tag; }
		void	setTag(int8 val) { m_buffer->Header.Tag = val; }
		int8	getExtend1() { return m_buffer->Header.Extend1; }
		void	setExtend1(int8 val) { m_buffer->Header.Extend1 = val; }
		int8	getExtend2() {return m_buffer->Header.Extend2;}
		void	setExtend2(int8 val) { m_buffer->Header.Extend2 = val; }
		const char * getUserId();
		void setUserId(const char * str);
		int8	getServerId() { return m_buffer->Header.ServerId; }
		void	setServerId(int8 val) { m_buffer->Header.ServerId = val; }
		int32 getIndex() { return handleEndianInt32(m_buffer->Header.Index); }
		void setIndex(int32 val) { m_buffer->Header.Index = handleEndianInt32(val); }
		int32 getCommand() { return handleEndianInt32(m_buffer->Header.Command); }
		void setCommand(int32 val) { m_buffer->Header.Command = handleEndianInt32(val); }
		int32 getDataLen() { return handleEndianInt32(m_buffer->Header.DataLen); }

		uint8 readByte();
		uint16 readWord();
		uint32 readDword();
		uint64 readDDword();
		float readFloat();
		double readDouble();
		const char * readText(int len);
		void * readData(int len);

		void writeByte(uint8 c);
		void writeWord(uint16 s);
		void writeDword(uint32 l);
		void writeDDword(uint64 ll);
		void writeFloat(float f);
		void writeDouble(double d);
		void writeText(const char *str, int len);
		void writeData(void *data, int len);

		Packet* getPacket() { return m_buffer; }

	private:
		static char m_str_buffer[1024 - HEADERSIZE]; // �ַ�������
		uint32 handleEndianInt32(uint32 val);

		int m_pos;
		Packet *m_buffer;
};

