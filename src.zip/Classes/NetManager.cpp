#include "NetManager.h"


NetManager* NetManager::self = new NetManager();

NetManager::NetManager()
{
	m_socket = new GameSocket();
	m_packet = new Packet();
	m_packet_stream = new PacketStream(m_packet);
}

NetManager::~NetManager()
{
	m_socket && (delete m_socket, true);
	m_packet && (delete m_packet, true);
	m_packet_stream && (delete m_packet_stream, true);
}

NetManager * NetManager::getInstance()
{
	return self;
}

bool NetManager::connect(const char * pszServerIP, int nServerPort, int nBlockSec, bool bKeepAlive)
{
	return m_socket->connect(pszServerIP, nServerPort, nBlockSec, bKeepAlive);
}

bool NetManager::send()
{
	return m_socket->sendPacket(*m_packet);
}
