﻿#pragma once

#ifdef WIN32
#include <WinSock2.h>
#include <windows.h>
#else
#include <sys/socket.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SOCKET int
#define SOCKET_ERROR -1
#define INVALID_SOCKET -1

#endif

#include <functional>

#include "def.h"
#include "Packet.h"

#ifndef CHECKF
#define CHECKF(x) \
do \
{ \
  if (!(x)) { \
    CCLOG("CHECKF", #x, __FILE__, __LINE__); \
    return 0; \
  } \
} while (0)
#endif

#define _MAX_MSGSIZE 16 * 1024      // 暂定一个消息最大为16k
#define BLOCKSECONDS    30          // INIT函数阻塞时间
#define INBUFSIZE   (64*1024)       //? 具体尺寸根据剖面报告调整  接收数据的缓存
#define OUTBUFSIZE  (8*1024)        //? 具体尺寸根据剖面报告调整。 发送数据的缓存，当不超过8K时，FLUSH只需要SEND一次

class GameSocket {
	public:
		GameSocket();
		virtual ~GameSocket();

		bool connect(const char* pszServerIP, int nServerPort, int nBlockSec = BLOCKSECONDS, bool bKeepAlive = false);
		bool sendPacket(Packet &pack);
		Packet* receivePacket();
		bool check(void);
		void destroy(void);
		SOCKET getSocket(void) const { return m_sockClient; }

		std::function<void()> getOnDisConnectCallback() { return m_disconnect_cb; }
		void setOnDisConnectCallback(std::function<void()> func) { m_disconnect_cb = func; }
	private:
		bool hasError();         // 是否发生错误，注意，异步模式未完成非错误
		void closeSocket();
  
		SOCKET  m_sockClient;

		// 解析包
		Packet m_analayse_pack;
		char* m_receive_ptr;

		std::function<void()> m_disconnect_cb;
};
