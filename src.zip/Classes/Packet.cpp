#include "Packet.h"

#pragma pack(push)
#pragma pack(1)

//����ת��������
typedef union
{
	uint8 charVal[8];
	uint16 shortVal[4];
	uint32 longVal[2];
	float floatVal[2];
	uint64 int64Val;
	double doubleVal;
}TYPEUNION;

#pragma pack(pop)

std::function<void(TYPEUNION *pu, int size)> _getEndianFunc()
{
	TYPEUNION u;
	u.longVal[0] = 0xFF0000FF;

	// ��С��ģʽΪ��׼
	if (u.shortVal[0] == 0x00FF && u.shortVal[1] == 0xFF00)
	{
		return [](TYPEUNION *pu, int size) {};
	}
	else
	{
		return [](TYPEUNION *pu, int size) {
			int dsize = size / 2;
			for (int i = 0; i < dsize; i++)
			{
				uint8 t = pu->charVal[i];
				pu->charVal[i] = pu->charVal[size - i - 1];
				pu->charVal[size - i - 1] = t;
			}
		};
	}
}

std::function<void(TYPEUNION *pu, int size)> _handleEndian = _getEndianFunc();

char PacketStream::m_str_buffer[1024 - HEADERSIZE];

PacketStream::PacketStream(Packet *pack)
{
	m_buffer = pack;
	moveToEnd();
}

PacketStream::~PacketStream()
{
	delete m_buffer;
}

void PacketStream::reset()
{
	move(0);
	m_buffer->Header.DataLen = 0;
}

void PacketStream::moveToEnd()
{
	m_pos = m_buffer->Header.DataLen;
}

const char * PacketStream::getUserId()
{
	strncpy(m_str_buffer, m_buffer->Header.UserId, sizeof(PackHeader::UserId));
	int len = sizeof(PackHeader::UserId) - 1;
	while (m_str_buffer[len] == ' ') len--;
	m_str_buffer[len + 1] = 0;
	return m_str_buffer;
}

void PacketStream::setUserId(const char * str)
{
	char *dst = m_buffer->Header.UserId;
	int str_len = strlen(str);
	strncpy(dst, str, str_len);
	dst += str_len;
	memset(dst, ' ', sizeof(PackHeader::UserId) - str_len);
}


uint8 PacketStream::readByte()
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	m_pos++;
	return ret->charVal[0];
}
uint16 PacketStream::readWord()
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	_handleEndian(ret, sizeof(uint16));
	m_pos += sizeof(uint16);
	return ret->shortVal[0];
}
uint32 PacketStream::readDword()
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	_handleEndian(ret, sizeof(uint32));
	m_pos += sizeof(uint32);
	return ret->longVal[0];
}
uint64 PacketStream::readDDword()
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	_handleEndian(ret, sizeof(uint64));
	m_pos += sizeof(uint64);
	return ret->int64Val;
}
float PacketStream::readFloat()
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	_handleEndian(ret, sizeof(float));
	m_pos += sizeof(float);
	return ret->floatVal[0];
}
double PacketStream::readDouble()
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	_handleEndian(ret, sizeof(double));
	m_pos += sizeof(double);
	return ret->doubleVal;
}
const char * PacketStream::readText(int len)
{
	strncpy(m_str_buffer, (char*)(m_buffer->Data + m_pos), len);
	m_pos += len;
	len--;
	while (m_str_buffer[len] == ' ') len--;
	m_str_buffer[len + 1] = 0;
	return m_str_buffer;
}
void * PacketStream::readData(int len)
{
	memcpy(m_str_buffer, m_buffer->Data + m_pos, len);
	m_pos += len;
	return m_str_buffer;
}

void PacketStream::writeByte(uint8 c)
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	m_pos++;
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
	ret->charVal[0] = c;
}
void PacketStream::writeWord(uint16 s)
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	ret->shortVal[0] = s;
	_handleEndian(ret, sizeof(uint16));
	m_pos += sizeof(uint16);
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}
void PacketStream::writeDword(uint32 l)
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	ret->longVal[0] = l;
	_handleEndian(ret, sizeof(uint32));
	m_pos += sizeof(uint32);
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}
void PacketStream::writeDDword(uint64 ll)
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	ret->int64Val = ll;
	_handleEndian(ret, sizeof(uint64));
	m_pos += sizeof(uint64);
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}
void PacketStream::writeFloat(float f)
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	ret->floatVal[0] = f;
	_handleEndian(ret, sizeof(float));
	m_pos += sizeof(float);
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}
void PacketStream::writeDouble(double d)
{
	TYPEUNION *ret = (TYPEUNION *)(m_buffer->Data + m_pos);
	ret->doubleVal = d;
	_handleEndian(ret, sizeof(double));
	m_pos += sizeof(double);
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}
void PacketStream::writeText(const char *str, int len)
{
	char *dst = (char *)(m_buffer->Data + m_pos);
	int str_len = strlen(str);
	strncpy(dst, str, str_len);
	dst += str_len;
	memset(dst, ' ', len - str_len);
	m_pos += len;
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}
void PacketStream::writeData(void *data, int len)
{
	char *dst = (char *)(m_buffer->Data + m_pos);
	memcpy(dst, data, len);
	m_pos += len;
	if (m_buffer->Header.DataLen < m_pos) m_buffer->Header.DataLen = m_pos;
}

uint32 PacketStream::handleEndianInt32(uint32 val)
{
	TYPEUNION u;
	u.longVal[0] = val;
	_handleEndian(&u, sizeof(uint32));
	return u.longVal[0];
}
